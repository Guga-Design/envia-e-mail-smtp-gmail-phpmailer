﻿<?php

// Variáveis do Formulário Form 
$nome     = $_POST["nome"];  
$email    = $_POST["email"]; 
$assunto = $_POST["assunto"];  
$telefone = $_POST["telefone"]; 
$mensagem = $_POST["mensagem"]; 

// Inclui o arquivo class.phpmailer.php localizado na pasta phpmailer
include("class.phpmailer.php");

// Inicia a classe PHPMailer
$mail = new PHPMailer();

// Define os dados do servidor e tipo de conexão - NESTE CASO USAREMOS O GMAIL
$mail->IsSMTP();
$mail->Host     = "smtp.gmail.com";     // Endereço do servidor SMTP
$mail->SMTPAuth = true;                   // Usa autenticação SMTP? (opcional)
$mail->Username = 'seu-email@gmail.com';  // Usuário do servidor SMTP - IMPORTANTE - ATIVAR o acesso a aplicativos menos seguros da sua conta GMAIL	      
$mail->Password = 'suasenha';               // Senha do servidor SMTP
$mail->port = 587;                           // Autenticação 587 para conexões TLS 587 se for SSL é 465
$mail->SMTPSecure = 'tls';                  // Autenticação 587 TLS

// Define o remetente.
$mail->From     = "seu-email@gmail.com"; // Seu e-mail
$mail->FromName = "DISPARO DE EMAIL"; // Nome do disparo 

// Variáveis dos destinatário(s)
$destinatario1 = "destinatario1@gmail.com";
$destinatario2 = "destinatario2@hotmail.com"; 
$destinatario3 = "destinatario3@gmail.com"; 
$destinatario4 = "destinatario4@hotmail.com"; 
$destinatario5 = "destinatario5@gmail.com"; 

// Define os destinatário(s)
$mail->AddAddress($destinatario1);
$mail->AddAddress($destinatario2);
$mail->AddAddress($destinatario3);
$mail->AddAddress($destinatario4);
$mail->AddAddress($destinatario5);

// DEFININDO OS DADOS DO E-MAIL, ASSUNTO E MENSAGEM

// Corpo da Mensagem 
$mail->IsHTML(true); // Define que o e-mail será enviado em código HTML
$mail->Subject = "CLIENTE DO SITE PERGUNTA, $assunto";  // Assunto predefininido e Cliente preenchido.
// HTML do corpo do e-mail definindo que Nome, e-mail, telefone e mensagem apareceram no corpo.
$mail->Body    = "<h2>Nome do Cliente: $nome</h2><h3>Email do cliente: $email<h3/> <h3>TELEFONE/CELULAR: $telefone </h3> <br/> <h2> Mensagem: $mensagem </h2>"; 

// Envia o e-mail
$enviado = $mail->Send();

// Exibe uma mensagem de resultado
if ($enviado) {
   echo "E-mail enviado com sucesso!";   
} else {
   echo "Não foi possível enviar o e-mail !";
}

?>
